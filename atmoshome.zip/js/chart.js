// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = "Lato", "Arial", "Helvetica", "sans-serif";
Chart.defaults.global.defaultFontColor = '#858796';


var api_url = 'http://192.168.43.57:5000/atmos/';
var temp1 = document.getElementById('temp1');


init();

function init() {
  getDatas();
}

function getDatas() {
  var request = new XMLHttpRequest();


  var rrequest = request.open('GET', api_url, true);

  request.addEventListener('load', function() {
    //createChart(JSON.parse(request.response).bpi);
    changeText(JSON.parse(request.response).bpi);
  });

  request.send();


  
}



function createChart(data) {
  var keys = Object.keys(data);
  var chart_data = [];

  for (var i = 0; i < keys.length; i++) {
    chart_data.push(data[keys[i]]); // Parse datas
  }

  var chart = new Chart(btc, {
    type: 'line',
    data: {
      labels: keys,
      datasets: [{
        label: 'BTC / USD',
        backgroundColor: 'rgba(18, 156, 235, 0.4)',
        borderColor: 'rgba(5, 25, 55, 0.8)',
        data: chart_data,
      }]
    }
  });
}

function changeText(data) {
    
}
