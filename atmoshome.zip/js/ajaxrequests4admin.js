function addProbe(name){

    var x = getLocationX();
    var y = getLocationY();


    $.ajax({ 
        type:"POST", // GET = requesting data
        url:"http://192.168.43.57:5000/atmos/probe/add/" + name + "+" + x + "+" + y +"+0",
        headers: {"Access-Control-Allow-Headers": "*"},
        success: function() {
            
            console.log("Votre sonde a bien été ajouté au système.");
            
             // Set data that comes back from the server to 'tempDew1'
        },
        error: function() {

            alert("Une erreur s'est produite.");
        },
        dataType: 'json',
    });
    $('#AddProbe').modal('hide');
};

function delProbe(id){
    $.ajax({ 
        type:"PUT", // UPDATE
        url:"http://192.168.43.57:5000/atmos/probe/state/change/" + id,
        headers: {"Access-Control-Allow-Headers": "*"},
        success: function() {

            getStateProbe(function(rGetState){

                console.log("rGetState", rGetState);

                if (rGetState == 1) {
                    console.log("active");
                    if(document.getElementById("probeActive").classList.contains("btn-danger")) {
                        document.getElementById("probeActive").classList.remove("btn-danger");
                    }
                    if(document.getElementById("DelProbeBtnDisplay").classList.contains("btn-success")) {
                        document.getElementById("DelProbeBtnDisplay").classList.remove("btn-success");
                    }
                    if(document.getElementById("probeActive").classList.contains("btn-warning")) {
                        document.getElementById("probeActive").classList.remove("btn-warning");
                    }
                    document.getElementById("probeActive").classList.add("btn-success");
                    document.getElementById("DelProbeBtnDisplay").classList.add("btn-danger");
                    $('#probeActive').text("Sonde activée");
                    $('#DelProbeBtnText').text("Désactiver la sonde");

                    $('#DelProbeLabel').text("Désactivation");
                    $('#DelProbeText').text("Voulez-vous désactiver DewDrop du Garage ?");
                    $('#DelProbeBtn').text("Désactiver");

                    if(document.getElementById("borderModal").classList.contains("border-bottom-success")) {
                        document.getElementById("borderModal").classList.remove("border-bottom-success");
                    }
                    document.getElementById("borderModal").classList.add("border-bottom-danger");
                    if(document.getElementById("DelProbeBtn").classList.contains("btn-success")) {
                        document.getElementById("DelProbeBtn").classList.remove("btn-success");
                    }
                    document.getElementById("DelProbeBtn").classList.add("btn-danger");

                } else {
                    if(rGetState == 0){
                        console.log("not active");
                        if(document.getElementById("probeActive").classList.contains("btn-success")) {
                            document.getElementById("probeActive").classList.remove("btn-success");
                        }
                        if(document.getElementById("DelProbeBtnDisplay").classList.contains("btn-danger")) {
                            document.getElementById("DelProbeBtnDisplay").classList.remove("btn-danger");
                        }
                        if(document.getElementById("probeActive").classList.contains("btn-warning")) {
                            document.getElementById("probeActive").classList.remove("btn-warning");
                        }
                        document.getElementById("probeActive").classList.add("btn-danger");
                        document.getElementById("DelProbeBtnDisplay").classList.add("btn-success");
                        $('#probeActive').text("Sonde désactivée");
                        $('#DelProbeBtnText').text("Activer la sonde");


                        $('#DelProbeLabel').text("Activation");
                        $('#DelProbeText').text("Voulez-vous réactiver DewDrop du Garage ?");
                        $('#DelProbeBtn').text("Activer");

                        if(document.getElementById("borderModal").classList.contains("border-bottom-danger")) {
                            document.getElementById("borderModal").classList.remove("border-bottom-danger");
                        }
                        document.getElementById("borderModal").classList.add("border-bottom-success");
                        if(document.getElementById("DelProbeBtn").classList.contains("btn-danger")) {
                            document.getElementById("DelProbeBtn").classList.remove("btn-danger");
                        }
                        document.getElementById("DelProbeBtn").classList.add("btn-success");



                        
                    } else {
                        console.log("other");
                        if(document.getElementById("probeActive").classList.contains("btn-success")) {
                            document.getElementById("probeActive").classList.remove("btn-success");
                        }
                        if(document.getElementById("probeActive").classList.contains("btn-danger")) {
                            document.getElementById("probeActive").classList.remove("btn-danger");
                        }
                        document.getElementById("probeActive").classList.add("btn-warning");
                        $('#probeActive').text("Etat de la sonde inconnu");
                    }
                    
                }
            });

        },
        error: function() {
            alert("Une erreur s'est produite.");
        },
        dataType: 'json',
    });
    $('#DelProbe').modal('hide');
};

function getStateProbe(callback){
    $.ajax({ 
        type:"GET", // UPDATE
        url:"http://192.168.43.57:5000/atmos/probe/",
        headers: {"Access-Control-Allow-Headers": "*"},
        success: function(data) {
            if(data[1].active == "1") {
                callback(1);
            } else {
                callback(0);
            }
        },
        error: function() {
            callback(-1);

        },
        dataType: 'json',
    });
};




$(document).ready(function() {
    $('#btnAddProbe').click(function () {
        addProbe($("#ProbeName").val());
    });

    $('#DelProbeBtn').click(function () {
        delProbe(2);
    });


    
});

$(document).ready(function() {
    getStateProbe(function(state){
        console.log('init state', state)
        if (state = 1) {
            document.getElementById("probeActive").classList.add("btn-success");
            document.getElementById("DelProbeBtnDisplay").classList.add("btn-danger");
            $('#probeActive').text("Sonde activée");
            $('#DelProbeBtnText').text("Désactiver la sonde");


            $('#DelProbeLabel').text("Désactivation");
            $('#DelProbeText').text("Voulez-vous désactiver DewDrop du Garage ?");
            $('#DelProbeBtn').text("Désactiver");
        } else {
            if (state = 0) {
                document.getElementById("probeActive").classList.add("btn-danger");
                document.getElementById("DelProbeBtnDisplay").classList.add("btn-success");
                $('#probeActive').text("Sonde désactivée");
                $('#DelProbeBtnText').text("Activer la sonde");


                $('#DelProbeLabel').text("Activation");
                $('#DelProbeText').text("Voulez-vous réactiver DewDrop du Garage ?");
                $('#DelProbeBtn').text("Activer");
            } else {
                document.getElementById("probeActive").classList.add("btn-warning");
                $('#probeActive').text("Etat de la sonde inconnu");
            }
            
            
        }
    });
  
    
    
});

function getLocationX() {
    var returnValue = 0;
    if (navigator.geolocation) {
        returnValue = navigator.geolocation.watchPosition(function (position) {return position.coords.latitude;});
    } else { 
        alert("La géolocation n'est pas supporté sur ce navigateur.");
    }
    return returnValue;
    
}

function getLocationY() {
    var returnValue = 0;
    if (navigator.geolocation) {
        returnValue = navigator.geolocation.watchPosition(function (position) {return position.coords.longitude;});
    } else { 
        alert("La géolocation n'est pas supporté sur ce navigateur.");
    }
    return returnValue;
    
}